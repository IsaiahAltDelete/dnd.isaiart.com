"""Copy Homebrewery fonts/textures into assets/, convert textures to WebP,
and pre-tint the watercolor stains (alpha x #BBAD82) so they work as plain
background images inside CSS columns (CSS mask breaks there in Chromium)."""
import shutil, sys
from pathlib import Path
from PIL import Image

HB = Path(sys.argv[1])          # path to the homebrewery clone
OUT = Path(__file__).resolve().parent.parent / "assets"
FONTS = {
    "Bookinsanity.woff2": "Bookinsanity.woff2",
    "Bookinsanity Bold.woff2": "Bookinsanity-Bold.woff2",
    "Bookinsanity Italic.woff2": "Bookinsanity-Italic.woff2",
    "Bookinsanity Bold Italic.woff2": "Bookinsanity-BoldItalic.woff2",
    "Mr Eaves Small Caps.woff2": "MrEavesSmallCaps.woff2",
    "Scaly Sans.woff2": "ScalySans.woff2",
    "Scaly Sans Bold.woff2": "ScalySans-Bold.woff2",
    "Scaly Sans Italic.woff2": "ScalySans-Italic.woff2",
    "Scaly Sans Bold Italic.woff2": "ScalySans-BoldItalic.woff2",
    "Scaly Sans Caps.woff2": "ScalySansCaps.woff2",
    "Solbera Imitation Tweak.woff2": "SolberaImitation.woff2",
    "Nodesto Caps Condensed.woff2": "NodestoCapsCondensed.woff2",
    "WalterTurncoat-Regular.woff2": "WalterTurncoat.woff2",
    "Overpass Medium.woff2": "Overpass-Medium.woff2",
}
(OUT / "fonts").mkdir(parents=True, exist_ok=True)
for src, dst in FONTS.items():
    shutil.copy(HB / "themes/fonts/5e" / src, OUT / "fonts" / dst)

A = HB / "themes/assets"
def webp(name, out, q=82, lossless=False, max_w=None):
    im = Image.open(A / name).convert("RGBA")
    if max_w and im.width > max_w:
        im = im.resize((max_w, round(im.height * max_w / im.width)), Image.LANCZOS)
    im.save(OUT / out, "WEBP", quality=q, lossless=lossless, method=6)

webp("parchmentBackground.jpg", "parchment.webp", q=78, max_w=1600)
webp("parchmentBackgroundGrayscale.jpg", "parchment-gray.webp", q=75, max_w=1200)
webp("PHB_footerAccent.png", "footer-accent.webp", lossless=True, max_w=1600)
for n in ["noteBorder", "descriptiveBorder", "redTriangle", "monsterBorderFancy",
          "frameBorder", "classTableDecoration"]:
    webp(f"{n}.png", f"{n}.webp", lossless=True)
for n in ["horizontalRule.svg", "coverPageBanner.svg"]:
    shutil.copy(A / n, OUT / n)

# Pre-tinted watercolor stains
tint = (0xBB, 0xAD, 0x82)
for i in (1, 2, 3, 4, 5, 6, 8, 10):
    src = Image.open(A / f"watercolor/watercolor{i}.png").convert("RGBA")
    alpha = src.getchannel("A")
    # boost a little: Homebrewery renders these at full mask strength
    alpha = alpha.point(lambda v: min(255, round(v * 1.15)))
    out = Image.new("RGBA", src.size, tint + (0,))
    out.putalpha(alpha)
    out.save(OUT / f"stain{i}.webp", "WEBP", quality=80, method=6)
print("done", sorted(p.name for p in OUT.iterdir()))
