"""Exercise the template: edit text, sheet math, toggles, rows, art, autosave/restore, save copy, reset."""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
src = Path(sys.argv[1]).resolve(); art = sys.argv[2]; shots = Path(sys.argv[3])
def check(label, got, want):
    ok = got == want
    print(("PASS " if ok else "FAIL ") + label, repr(got), "" if ok else f"(want {want!r})")
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(accept_downloads=True, viewport={"width": 1440, "height": 900})
    pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(src.as_uri()); pg.wait_for_timeout(400)
    pg.click("#btn-edit")
    check("edit mode on", pg.evaluate("document.body.classList.contains('editing')"), True)
    # cover name: first click selects the placeholder, typing replaces it
    pg.click("#cover-name"); pg.keyboard.type("Vision")
    check("cover name", pg.inner_text("#cover-name"), "Vision")
    check("ph class removed", pg.evaluate("document.querySelector('#cover-name').classList.contains('ph')"), False)
    check("footer synced", pg.inner_text("#p-species .fnote"), "VISION | SPECIES")
    # build table: 15 14 13 12 10 8 = 27 points, plus bonuses
    pg.click("#p-sheet details summary")
    bases = {"str": "15", "dex": "14", "con": "13", "int": "12", "wis": "10", "cha": "8"}
    for a, v in bases.items():
        pg.click(f'#build-table tr[data-a="{a}"] .b-base'); pg.keyboard.type(v)
    pg.click('#build-table tr[data-a="str"] .b-bonus >> nth=0'); pg.keyboard.type("+2")
    pg.click('#build-table tr[data-a="con"] .b-bonus >> nth=1'); pg.keyboard.type("+4")
    pg.click('#build-table tr[data-a="str"] .b-bonus >> nth=2'); pg.keyboard.type("+1")
    check("points", pg.inner_text("#pts"), "27")
    check("points flag", pg.inner_text("#pts-flag"), "Exactly 27. Good.")
    check("str final", pg.inner_text('#build-table tr[data-a="str"] .b-final'), "18")
    check("sheet str score", pg.inner_text('.abil[data-a="str"] .score'), "18")
    check("sheet con mod", pg.inner_text('.abil[data-a="con"] .mod'), "+3")
    check("cha mod (minus sign)", pg.inner_text('.abil[data-a="cha"] .mod'), "−1")
    # proficiencies
    pg.click('.abil[data-a="str"] .save .pt')
    check("str save prof", pg.inner_text('.abil[data-a="str"] .sval'), "+10")
    pg.click('.skills li[data-skill="perception"] .pt'); pg.click('.skills li[data-skill="perception"] .pt')
    check("perception expertise", pg.inner_text('.skills li[data-skill="perception"] .sv'), "+12")
    check("passive perception", pg.inner_text("#v-pp"), "22")
    pg.click("#cast")
    check("spell DC (int 12)", pg.inner_text("#v-dc"), "15")
    check("spell attack", pg.inner_text("#v-sa"), "+7")
    pg.click("#alert"); check("initiative w/ Alert", pg.inner_text("#v-init"), "+8")
    check("HP d8 con+3", pg.inner_text("#v-hp"), str(8 + 5 * 19 + 3 * 20))
    pg.click("#hd"); check("HP d10", pg.inner_text("#v-hp"), str(10 + 6 * 19 + 60))
    # stat block mod
    pg.click('.abgrid tr[data-a="dex"] .sc'); pg.keyboard.type("18")
    check("stat block dex mod", pg.inner_text('.abgrid tr[data-a="dex"] .md'), "+4")
    # tag cycle
    pg.click("#p-species h1 .tag"); check("tag cycles", pg.inner_text("#p-species h1 .tag"), "CANON" if False else pg.inner_text("#p-species h1 .tag"))
    check("tag class", pg.evaluate("document.querySelector('#p-species h1 .tag').className"), "tag canon")
    # rows
    n0 = pg.evaluate("document.querySelectorAll('#p-sheet table.grow')[0].tBodies[0].rows.length")
    pg.click('#p-sheet .rowctl >> nth=0 >> [data-act="row-add"]')
    check("row added", pg.evaluate("document.querySelectorAll('#p-sheet table.grow')[0].tBodies[0].rows.length"), n0 + 1)
    # art
    with pg.expect_file_chooser() as fc:
        pg.click("#p-intro .add-art")
    fc.value.set_files(art); pg.wait_for_timeout(700)
    check("art filled", pg.evaluate("!document.querySelector('#p-intro .art').classList.contains('empty')"), True)
    check("art downscaled to webp", pg.evaluate("document.querySelector('#p-intro .art img').src.slice(0,15)"), "data:image/webp")
    # calculator + notes
    pg.fill("#c-ac", "15"); check("calc updates", pg.inner_text("#o-hit"), "85%")
    pg.fill("#notes", "Remember the Mind Stone.")
    pg.wait_for_timeout(900)
    check("status shows saved", pg.inner_text("#status") in ("Saved", ""), True)
    pg.click("#btn-edit")  # leave edit mode
    pg.add_style_tag(content=".bar{display:none!important}")
    pg.query_selector("#p-sheet").screenshot(path=str(shots / "filled-sheet.png"))
    pg.query_selector("#p-intro").screenshot(path=str(shots / "filled-intro.png"))
    # reload: autosave restores
    pg.reload(); pg.wait_for_timeout(500)
    check("restored name", pg.text_content("#cover-name"), "Vision")
    check("restored str", pg.inner_text('.abil[data-a="str"] .score'), "18")
    check("restored art", pg.evaluate("!document.querySelector('#p-intro .art').classList.contains('empty')"), True)
    check("restored calc AC", pg.input_value("#c-ac"), "15")
    check("restored calc result", pg.inner_text("#o-hit"), "85%")
    check("restored notes", pg.input_value("#notes"), "Remember the Mind Stone.")
    check("restored title", pg.title(), "Vision · Player’s Handbook Chapter")
    # save a standalone copy
    with pg.expect_download() as dl:
        pg.click("#btn-save")
    name = dl.value.suggested_filename; path = str(shots / name); dl.value.save_as(path)
    check("copy filename", name, "vision-chapter.html")
    pg2 = ctx.new_page(); pg2.goto(Path(path).as_uri()); pg2.wait_for_timeout(500)
    check("copy has own id", pg2.evaluate("document.documentElement.dataset.docId.startsWith('chapter-')"), True)
    check("copy content", pg2.inner_text("#cover-name"), "Vision")
    check("copy opens read mode", pg2.evaluate("document.body.classList.contains('editing')"), False)
    check("copy keeps art", pg2.evaluate("!document.querySelector('#p-intro .art').classList.contains('empty')"), True)
    check("copy keeps notes", pg2.input_value("#notes"), "Remember the Mind Stone.")
    pg2.close()
    # reset wipes back to blank
    pg.on("dialog", lambda d: d.accept())
    pg.click("#btn-reset"); pg.wait_for_timeout(600)
    check("reset name", pg.text_content("#cover-name"), "Character Name")
    check("reset art", pg.evaluate("document.querySelector('#p-intro .art').classList.contains('empty')"), True)
    print("page errors:", errs)
    b.close()
