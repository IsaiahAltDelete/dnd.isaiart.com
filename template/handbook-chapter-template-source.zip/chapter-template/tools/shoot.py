"""Screenshot every .page at desktop and phone widths; report console errors and overflow."""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

src = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
edit = len(sys.argv) > 3 and sys.argv[3] == "edit"
with sync_playwright() as p:
    b = p.chromium.launch()
    for name, w, scale in (("d", 1440, 1), ("m", 390, 2)):
        pg = b.new_page(viewport={"width": w, "height": 900}, device_scale_factor=scale)
        errs = []
        pg.on("console", lambda m: m.type in ("error", "warning") and errs.append(m.text))
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(src.as_uri()); pg.wait_for_timeout(600)
        if edit: pg.click("#btn-edit"); pg.wait_for_timeout(200)
        pg.add_style_tag(content=".bar,.editbanner{display:none!important}")
        sw = pg.evaluate("document.documentElement.scrollWidth")
        print(name, "scrollWidth", sw, "errors", errs)
        for i, el in enumerate(pg.query_selector_all(".page"), 1):
            box = el.bounding_box()
            el.screenshot(path=str(out / f"{name}{'e' if edit else ''}-{i:02d}.png"))
            print(f"  page {i}: {box['width']:.0f}x{box['height']:.0f}")
        pg.close()
    b.close()
