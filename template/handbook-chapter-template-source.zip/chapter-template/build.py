"""Build one self-contained, offline HTML file from src.html + style.css + app.js + assets/.
Usage: python3 build.py [output.html]"""
import base64, re, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "dist" / "handbook-chapter-template.html"
MIME = {".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".woff2": "font/woff2"}

def data_uri(path: Path) -> str:
    b = base64.b64encode(path.read_bytes()).decode()
    return f'"data:{MIME[path.suffix]};base64,{b}"'

css = (HERE / "style.css").read_text()
css = re.sub(r"\{\{font:([^}]+)\}\}", lambda m: data_uri(HERE / "assets/fonts" / m.group(1)), css)
css = re.sub(r"\{\{img:([^}]+)\}\}", lambda m: data_uri(HERE / "assets" / m.group(1)), css)
assert "{{" not in css, "unreplaced asset token"
js = (HERE / "app.js").read_text()
assert "</script" not in js

html = (HERE / "src.html").read_text()
html = html.replace("/*STYLE*/", css, 1).replace("/*SCRIPT*/", js, 1)
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(html)
print(f"wrote {OUT} ({OUT.stat().st_size/1024:.0f} KB)")
