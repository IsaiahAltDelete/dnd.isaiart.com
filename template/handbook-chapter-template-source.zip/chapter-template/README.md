# Handbook Chapter Template

A blank Player's Handbook-style D&D 2024 character chapter, built as one offline HTML file in the Homebrewery 5e PHB look. It's the empty version of the `dnd-handbook-chapter` workflow: same 11 sections, same order, ready to fill in.

## Using the finished file

Open `dist/handbook-chapter-template.html` in any browser. No internet needed.

- **Edit** turns on click-to-type. Tapping a placeholder selects it, so typing replaces it. Blue tips (the authoring rules from the skill) only show in Edit mode.
- **Cover name** fills every `[Character Name]` placeholder in the chapter until you type over one by hand. Footers and the contents list update themselves.
- **Level 20 sheet** does its own math: fill the point-buy table under "How the Numbers Were Built" (it checks for exactly 27) and the scores, modifiers, saves, skills, passive Perception, spell DC, initiative, and average HP all follow. Tap circles for proficiency; tap a skill twice for Expertise.
- **Art slots**: tap "Add art". Images are shrunk to WebP and stored inside the page.
- **+ Row / − Row** under tables in Edit mode.
- **Labels** (Official / Homebrew / Canon): tap one in Edit mode to cycle it.
- **Combat Math** calculator works in both modes.
- **Autosave** keeps your work in this browser. **Save copy** downloads a finished, standalone HTML file with everything baked in (that copy keeps its own separate autosave). **Reset** wipes back to blank.
- **Print** fits each page onto one letter sheet.

## Rebuilding from source

```
python3 build.py            # writes dist/handbook-chapter-template.html
```

`src.html` (markup), `style.css` (theme), and `app.js` (behavior) are inlined with every font and texture in `assets/` as base64. `tools/prep_assets.py <homebrewery clone>` regenerates `assets/` from a sparse clone of naturalcrit/homebrewery (`themes/fonts`, `themes/assets`, `themes/V3/5ePHB`). `tools/shoot.py` screenshots every page at 1440px and 390px; `tools/interact.py` runs an end-to-end test.

To start a new character chapter with Claude, use this folder in place of copying the Vision build.

## Licensing

- Page design follows The Homebrewery 5e PHB theme by naturalcrit (MIT License, © 2016 Scott Tolksdorf). Parchment, borders, footer, class-table, and watercolor textures come from that project.
- Bookinsanity, Mr Eaves Small Caps, Scaly Sans, Solbera Imitation, and Nodesto Caps Condensed are fonts by Solbera (CC BY-SA 4.0), as remade by The Homebrewery. Walter Turncoat: Apache License 2.0. Overpass: SIL Open Font License 1.1.
- Rules text patterns follow the SRD 5.2.1 (CC BY 4.0); the attribution line is on the Sources page.
- Any art you add makes a filled copy personal-use only unless you have rights to that art.
