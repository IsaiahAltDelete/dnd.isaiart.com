(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var root = document.documentElement;
  var KEY = 'phb-chapter:' + (root.getAttribute('data-doc-id') || 'template');

  // ---------- storage (every call guarded: private windows / file:// can throw) ----------
  var store = {
    get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem(k, v); return true; } catch (e) { return false; } },
    del: function (k) { try { window.localStorage.removeItem(k); } catch (e) { /* ignore */ } }
  };
  var statusEl = $('#status'), statusTimer = null;
  function status(t, sticky) {
    if (!statusEl) return;
    statusEl.textContent = t;
    clearTimeout(statusTimer);
    if (!sticky) statusTimer = setTimeout(function () { statusEl.textContent = ''; }, 2200);
  }

  // ---------- helpers ----------
  function clean(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
  function num(el) {
    if (!el) return null;
    var m = (el.textContent || '').replace(/−/g, '-').match(/-?\d+/);
    return m ? parseInt(m[0], 10) : null;
  }
  function fmt(n) { return n >= 0 ? '+' + n : '−' + Math.abs(n); }
  function abilityMod(s) { return Math.floor((s - 10) / 2); }
  var NAMES = { str: 'Str', dex: 'Dex', con: 'Con', int: 'Int', wis: 'Wis', cha: 'Cha' };
  var COST = { 8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 13: 5, 14: 7, 15: 9 };

  // ---------- restore saved work ----------
  (function restore() {
    var raw = store.get(KEY);
    if (!raw) return;
    try {
      var data = JSON.parse(raw);
      var pages = $$('.page');
      if (!data || data.v !== 1 || !data.pages || data.pages.length !== pages.length) return;
      pages.forEach(function (p, i) { p.innerHTML = data.pages[i]; });
      $$('textarea').forEach(function (t) { t.value = t.textContent; });
    } catch (e) { /* bad data: keep the blank template */ }
  })();

  // ---------- sheet math ----------
  function recalc() {
    var pbN = num($('#pb')), PB = pbN == null ? 6 : pbN;

    // build table -> finals -> sheet scores
    var spent = 0, any = false, bad = false;
    $$('#build-table tbody tr').forEach(function (tr) {
      var base = num($('.b-base', tr)), fin = $('.b-final', tr);
      if (base == null) { fin.textContent = '—'; return; }
      any = true;
      if (COST[base] == null) bad = true; else spent += COST[base];
      var f = base;
      $$('.b-bonus', tr).forEach(function (c) { var v = num(c); if (v != null) f += v; });
      fin.textContent = f;
      var sc = $('.abil[data-a="' + tr.getAttribute('data-a') + '"] .score');
      if (sc && sc.textContent !== String(f)) { sc.textContent = f; sc.classList.remove('ph'); }
    });
    var pts = $('#pts'), flag = $('#pts-flag');
    if (pts) pts.textContent = spent;
    if (flag) {
      if (!any) { flag.textContent = ''; flag.className = ''; }
      else if (bad) { flag.textContent = 'Base scores must be 8 to 15'; flag.className = 'warn'; }
      else if (spent === 27) { flag.textContent = 'Exactly 27. Good.'; flag.className = 'ok'; }
      else if (spent < 27) { flag.textContent = (27 - spent) + ' points left'; flag.className = 'warn'; }
      else { flag.textContent = 'Over by ' + (spent - 27); flag.className = 'warn'; }
    }

    // abilities and saves
    var mods = {};
    $$('.abil').forEach(function (b) {
      var s = num($('.score', b)), m = s == null ? null : abilityMod(s);
      mods[b.getAttribute('data-a')] = m;
      $('.mod', b).textContent = m == null ? '—' : fmt(m);
      var prof = $('.save .pt', b).getAttribute('data-p') === '1';
      $('.sval', b).textContent = m == null ? '—' : fmt(m + (prof ? PB : 0));
    });
    // skills
    $$('.skills li').forEach(function (li) {
      var m = mods[li.getAttribute('data-a')], p = +($('.pt', li).getAttribute('data-p') || 0);
      $('.sv', li).textContent = m == null ? '—' : fmt(m + p * PB);
    });
    var perc = $('.skills li[data-skill="perception"]');
    if ($('#v-pp')) $('#v-pp').textContent = mods.wis == null ? '—' :
      String(10 + mods.wis + (+($('.pt', perc).getAttribute('data-p') || 0)) * PB);

    // initiative (+PB with the Alert feat)
    var alertBtn = $('#alert');
    if (alertBtn) {
      var alertOn = alertBtn.getAttribute('data-on') === '1';
      alertBtn.textContent = 'Alert: ' + (alertOn ? 'on' : 'off');
      $('#v-init').textContent = mods.dex == null ? '—' : fmt(mods.dex + (alertOn ? PB : 0));
    }

    // spellcasting
    var cast = $('#cast');
    if (cast) {
      var ca = cast.getAttribute('data-a') || '';
      cast.textContent = 'ability: ' + (ca ? NAMES[ca] : '—');
      var cm = ca ? mods[ca] : null;
      $('#v-dc').textContent = cm == null ? '—' : String(8 + PB + cm);
      $('#v-sa').textContent = cm == null ? '—' : fmt(PB + cm);
      $('#dc-line').textContent = !ca ? 'Pick a spellcasting ability in the Spell Save DC box on the sheet.'
        : cm == null ? 'Enter a ' + NAMES[ca] + ' score to see the DC.'
        : '8 + PB (' + PB + ') + ' + NAMES[ca] + ' mod (' + fmt(cm) + ') = DC ' + (8 + PB + cm) +
          '. Spell attack = PB + mod = ' + fmt(PB + cm) + '.';
    }

    // hit points (average)
    var hd = $('#hd');
    if (hd) {
      var d = +hd.getAttribute('data-d') || 8, extra = num($('#hp-extra')) || 0, cmod = mods.con;
      $('#v-hd').textContent = '20d' + d;
      if (cmod == null) {
        $('#v-hp').textContent = '—';
        $('#hp-line').textContent = 'Enter a Constitution score. Formula: the full Hit Die at level 1, then the fixed average (half the die + 1) for levels 2 to 20, plus Con mod every level.';
      } else {
        var hp = d + (d / 2 + 1) * 19 + cmod * 20 + extra;
        $('#v-hp').textContent = hp;
        $('#hp-line').textContent = 'd' + d + ': ' + d + ' at level 1 + ' + (d / 2 + 1) + ' × 19 + Con ' + fmt(cmod) +
          ' × 20' + (extra ? ' + ' + extra : '') + ' = ' + hp + '.';
      }
    }

    // stat block modifiers
    $$('.abgrid tbody tr').forEach(function (tr) {
      var s = num($('.sc', tr));
      $('.md', tr).textContent = s == null ? '—' : fmt(abilityMod(s));
    });
  }

  // ---------- titles, footers, contents ----------
  function syncTitles() {
    var cover = $('#cover-name');
    var name = clean(cover && cover.textContent) || 'Character Name';
    // every "[Character Name]" placeholder follows the cover title until it's edited by hand
    var unnamed = !cover || cover.classList.contains('ph') || !clean(cover.textContent);
    $$('[data-name="auto"]').forEach(function (el) {
      if (!el.hasAttribute('data-ph')) el.setAttribute('data-ph', el.textContent);
      var want = unnamed ? el.getAttribute('data-ph') : name;
      if (el.textContent !== want) el.textContent = want;
      el.classList.toggle('ph', unnamed);
    });
    document.title = name + ' · Player’s Handbook Chapter';
    $$('.page').forEach(function (p) {
      var f = $('.fnote', p);
      if (f) f.textContent = name + ' | ' + (p.getAttribute('data-sec') || '');
    });
    $$('.toc a').forEach(function (a) {
      var pg = document.getElementById(a.getAttribute('href').slice(1));
      if (!pg) return;
      var h = pg.querySelector('h1');
      if (h) {
        var c = h.cloneNode(true);
        $$('.tag', c).forEach(function (t) { t.parentNode.removeChild(t); });
        $('.t', a).textContent = clean(c.textContent);
      }
      var n = $('.pnum', pg);
      $('.n', a).textContent = n ? clean(n.textContent) : '';
    });
  }

  // ---------- combat math ----------
  function parseDamage(str) {
    var s = (str || '').replace(/−/g, '-').replace(/\s+/g, ''), dice = 0, flat = 0, m;
    var re = /([+-]?)(\d*)d(\d+)|([+-]?)(\d+(?:\.\d+)?)/gi;
    while ((m = re.exec(s))) {
      if (m[3]) dice += (m[1] === '-' ? -1 : 1) * (m[2] ? +m[2] : 1) * (+m[3] + 1) / 2;
      else if (m[5]) flat += (m[4] === '-' ? -1 : 1) * (+m[5]);
    }
    return { dice: dice, flat: flat, avg: dice + flat };
  }
  function pRoll(r, mode) { return mode === 'a' ? (2 * r - 1) / 400 : mode === 'd' ? (41 - 2 * r) / 400 : 0.05; }
  function attackOdds(atk, ac, critMin, mode) {
    var hit = 0, crit = 0;
    for (var r = 2; r <= 20; r++) {            // a natural 1 always misses
      var p = pRoll(r, mode);
      if (r >= critMin) crit += p;              // crits always hit
      else if (r + atk >= ac) hit += p;
    }
    return { hit: hit, crit: crit, miss: 1 - hit - crit };
  }
  function n1(x) { return (Math.round(x * 10) / 10).toFixed(1); }
  function pct(x) { return Math.round(x * 100) + '%'; }
  function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }

  function runCalc() {
    if (!$('#c-atk')) return;
    var atk = +val('c-atk') || 0, ac = +val('c-ac') || 10, critMin = +val('c-crit') || 20,
        mode = val('c-mode'), n = Math.max(1, +val('c-n') || 1);
    var dmg = parseDamage(val('c-dmg')), xc = parseDamage(val('c-xcrit')), miss = parseDamage(val('c-miss'));
    var onHit = dmg.avg, onCrit = 2 * dmg.dice + dmg.flat + 2 * xc.dice + xc.flat;
    function perAttack(acv) {
      var o = attackOdds(atk, acv, critMin, mode);
      return { o: o, e: o.hit * onHit + o.crit * onCrit + o.miss * miss.avg };
    }
    var cur = perAttack(ac);
    $('#o-turn').textContent = n1(cur.e * n);
    $('#o-hit').textContent = pct(cur.o.hit + cur.o.crit);
    $('#o-crit').textContent = pct(cur.o.crit);
    $('#o-avg').textContent = n1(onHit) + ' / ' + n1(onCrit);
    $('#o-per').textContent = n1(cur.e);

    // armor class sweep
    var table = $('#sweep');
    if (table) {
      var head = '<tr><th>Target AC</th>', hitRow = '<tr><td>Hit chance</td>', dmgRow = '<tr><td>Damage per turn</td>';
      for (var a = 12; a <= 24; a += 2) {
        var r = perAttack(a), here = a === ac ? ' style="font-weight:800;color:var(--head)"' : '';
        head += '<th class="c"' + here + '>' + a + '</th>';
        hitRow += '<td class="c"' + here + '>' + pct(r.o.hit + r.o.crit) + '</td>';
        dmgRow += '<td class="c"' + here + '>' + n1(r.e * n) + '</td>';
      }
      table.innerHTML = '<thead>' + head + '</tr></thead><tbody>' + hitRow + '</tr>' + dmgRow + '</tr></tbody>';
    }

    // saving throw
    var dc = +val('s-dc') || 10, bonus = +val('s-bonus') || 0, smode = val('s-mode'),
        sn = Math.max(1, +val('s-n') || 1), half = val('s-half') === 'half', sd = parseDamage(val('s-dmg'));
    var fail = 0;
    for (var r2 = 1; r2 <= 20; r2++) if (r2 + bonus < dc) fail += pRoll(r2, smode);
    var onSucc = half ? sd.avg / 2 : 0, per = fail * sd.avg + (1 - fail) * onSucc;
    $('#o-sfail').textContent = pct(fail);
    $('#o-savg').textContent = n1(sd.avg) + ' / ' + n1(onSucc);
    $('#o-sper').textContent = n1(per);
    $('#o-stotal').textContent = n1(per * sn);
  }

  // ---------- form state <-> markup (so saves and copies keep values) ----------
  function syncForms() {
    $$('input').forEach(function (i) {
      if (i.type === 'file') return;
      if (i.type === 'checkbox') { if (i.checked) i.setAttribute('checked', ''); else i.removeAttribute('checked'); }
      else i.setAttribute('value', i.value);
    });
    $$('select').forEach(function (s) {
      Array.prototype.forEach.call(s.options, function (o) { if (o.selected) o.setAttribute('selected', ''); else o.removeAttribute('selected'); });
    });
    $$('textarea').forEach(function (t) { t.textContent = t.value; });
  }

  // ---------- autosave ----------
  var saveTimer = null;
  function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 500); }
  function saveNow() {
    saveTimer = null;
    syncForms();
    var ok = store.set(KEY, JSON.stringify({ v: 1, pages: $$('.page').map(function (p) { return p.innerHTML; }) }));
    status(ok ? 'Saved' : 'Too big to autosave. Use Save copy.', !ok);
  }
  window.addEventListener('pagehide', function () { if (saveTimer) saveNow(); });
  document.addEventListener('visibilitychange', function () { if (document.hidden && saveTimer) saveNow(); });

  // ---------- edit mode ----------
  var btnEdit = $('#btn-edit');
  function setEditing(on) {
    document.body.classList.toggle('editing', on);
    $$('.page').forEach(function (p) { if (on) p.setAttribute('contenteditable', 'true'); else p.removeAttribute('contenteditable'); });
    btnEdit.classList.toggle('on', on);
    btnEdit.textContent = on ? 'Done' : 'Edit';
    try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) { /* ignore */ }
  }
  function editing() { return document.body.classList.contains('editing'); }

  // ---------- art ----------
  var fileInput = $('#art-input'), artTarget = null;
  var POS = ['50% 30%', '50% 50%', '50% 75%', '50% 10%'];
  function pickArt(fig) { artTarget = fig; fileInput.value = ''; fileInput.click(); }
  function loadImage(file, max) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onerror = rej;
      fr.onload = function () {
        var im = new Image();
        im.onerror = rej;
        im.onload = function () {
          var scale = Math.min(1, max / Math.max(im.width, 1));
          var w = Math.round(im.width * scale), h = Math.round(im.height * scale);
          var c = document.createElement('canvas'); c.width = w; c.height = h;
          c.getContext('2d').drawImage(im, 0, 0, w, h);
          var url = '';
          try { url = c.toDataURL('image/webp', 0.86); } catch (e) { url = ''; }
          if (url.indexOf('data:image/webp') !== 0) url = c.toDataURL('image/jpeg', 0.88);
          res(url);
        };
        im.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  fileInput.addEventListener('change', function () {
    var f = fileInput.files && fileInput.files[0], fig = artTarget;
    if (!f || !fig) return;
    loadImage(f, +fig.getAttribute('data-max') || 1400).then(function (url) {
      $('img', fig).src = url;
      fig.classList.remove('empty');
      scheduleSave();
    }).catch(function () { status('Could not read that image'); });
  });

  // ---------- clicks ----------
  document.addEventListener('click', function (e) {
    var t = e.target, el;
    if (t.closest('#btn-edit')) { setEditing(!editing()); return; }
    if (t.closest('#btn-save')) { saveCopy(); return; }
    if (t.closest('#btn-print')) { window.print(); return; }
    if (t.closest('#btn-reset')) {
      if (window.confirm('Wipe every change and go back to how this file was when you opened it?')) {
        clearTimeout(saveTimer); saveTimer = null; store.del(KEY); window.location.reload();
      }
      return;
    }
    if ((el = t.closest('.pt')) && !el.closest('.skills-key')) {
      var max = el.closest('.skills') ? 2 : 1, p = (+(el.getAttribute('data-p') || 0) + 1) % (max + 1);
      el.setAttribute('data-p', p); recalc(); scheduleSave(); return;
    }
    if ((el = t.closest('#hd'))) {
      var dice = [6, 8, 10, 12], cur = dice.indexOf(+el.getAttribute('data-d'));
      el.setAttribute('data-d', dice[(cur + 1) % dice.length]); recalc(); scheduleSave(); return;
    }
    if ((el = t.closest('#alert'))) { el.setAttribute('data-on', el.getAttribute('data-on') === '1' ? '0' : '1'); recalc(); scheduleSave(); return; }
    if ((el = t.closest('#cast'))) {
      var order = ['', 'int', 'wis', 'cha'], ci = order.indexOf(el.getAttribute('data-a') || '');
      el.setAttribute('data-a', order[(ci + 1) % order.length]); recalc(); scheduleSave(); return;
    }
    if ((el = t.closest('.tag')) && editing()) {
      var kinds = [['off', 'Official'], ['hb', 'Homebrew'], ['canon', 'Canon']], k = 0;
      kinds.forEach(function (x, i) { if (el.classList.contains(x[0])) k = i; });
      el.classList.remove(kinds[k][0]); k = (k + 1) % 3;
      el.classList.add(kinds[k][0]); el.textContent = kinds[k][1];
      scheduleSave(); return;
    }
    var fig = t.closest('.art');
    if (fig && (t.closest('.add-art') || t.closest('[data-act="art-swap"]'))) { pickArt(fig); return; }
    if (fig && t.closest('[data-act="art-del"]')) {
      $('img', fig).removeAttribute('src'); fig.classList.add('empty'); scheduleSave(); return;
    }
    if (fig && t.closest('[data-act="art-pos"]')) {
      var img = $('img', fig), i2 = POS.indexOf(fig.getAttribute('data-pos')), next = POS[(i2 + 1) % POS.length];
      fig.setAttribute('data-pos', next); img.style.objectPosition = next; scheduleSave(); return;
    }
    if ((el = t.closest('[data-act="row-add"],[data-act="row-del"]'))) {
      var table = el.closest('.rowctl').previousElementSibling;
      if (!table || table.tagName !== 'TABLE') return;
      var body = table.tBodies[0], rows = body.rows;
      if (el.getAttribute('data-act') === 'row-add') {
        var last = rows[rows.length - 1], copy = last.cloneNode(true);
        Array.prototype.forEach.call(copy.cells, function (c) { c.textContent = '—'; c.classList.add('ph'); });
        body.appendChild(copy);
      } else if (rows.length > 1) {
        body.removeChild(rows[rows.length - 1]);
      }
      scheduleSave(); return;
    }
    // placeholders: first tap selects the whole thing so typing replaces it
    if (editing() && (el = t.closest('.ph')) && el.closest('.page')) {
      var sel = window.getSelection();
      if (sel && sel.isCollapsed) {
        var range = document.createRange(); range.selectNodeContents(el);
        sel.removeAllRanges(); sel.addRange(range);
      }
    }
  });

  // ---------- typing ----------
  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t.closest && t.closest('.calc')) { runCalc(); scheduleSave(); return; }
    if (t.tagName === 'TEXTAREA') { scheduleSave(); return; }
    var sel = window.getSelection(), n = sel && sel.anchorNode;
    var at = n ? (n.nodeType === 1 ? n : n.parentElement) : null, ph = at && at.closest('.ph');
    var linked = at && at.closest('[data-name]');
    if (linked) linked.setAttribute('data-name', 'manual');   // typed over: stop mirroring the cover
    if (ph) ph.classList.remove('ph');
    recalc(); syncTitles(); scheduleSave();
  });
  document.addEventListener('change', function (e) {
    if (e.target.closest && e.target.closest('.calc')) { runCalc(); scheduleSave(); }
  });
  document.addEventListener('toggle', function () { scheduleSave(); }, true);
  // keep pasted text plain so it takes the page's fonts
  document.addEventListener('paste', function (e) {
    if (!editing() || !e.target.closest || !e.target.closest('.page') || e.target.closest('.calc,.notes')) return;
    var text = e.clipboardData && e.clipboardData.getData('text/plain');
    if (text == null) return;
    e.preventDefault();
    document.execCommand('insertText', false, text);
  });

  // ---------- save a standalone copy ----------
  function slug(s) { return (s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'chapter'; }
  function saveCopy() {
    syncForms(); syncTitles();
    var was = editing();
    if (was) setEditing(false);
    var clone = root.cloneNode(true);
    if (was) setEditing(true);
    clone.setAttribute('data-doc-id', 'chapter-' + Date.now().toString(36));
    var st = clone.querySelector('#status'); if (st) st.textContent = '';
    var html = '<!doctype html>\n' + clone.outerHTML;
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
    a.download = slug(clean($('#cover-name') && $('#cover-name').textContent)) + '-chapter.html';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.parentNode.removeChild(a); }, 1500);
    status('Copy downloaded');
  }

  // ---------- print: shrink any page taller than a letter sheet so it prints on one ----------
  var LETTER = 1056; // 11in at 96dpi; every page has at least this min-height
  function fitPages() {
    $$('.page').forEach(function (p) {
      p.style.zoom = ''; p.style.width = ''; p.style.minHeight = ''; p.style.maxWidth = '';
      var r = p.getBoundingClientRect();
      if (r.width < 800 || r.height <= LETTER + 1) return;   // phones lay out differently; skip
      var z = (LETTER - 8) / r.height;
      for (var i = 0; i < 4; i++) {
        p.style.maxWidth = 'none';
        p.style.width = (816 / z) + 'px';
        p.style.minHeight = (1056 / z) + 'px';
        p.style.zoom = z;
        var h = p.getBoundingClientRect().height;
        if (h <= LETTER + 1) break;
        z = z * (LETTER - 8) / h;
      }
    });
  }
  function unfitPages() { $$('.page').forEach(function (p) { p.style.zoom = ''; p.style.width = ''; p.style.minHeight = ''; p.style.maxWidth = ''; }); }
  window.addEventListener('beforeprint', fitPages);
  window.addEventListener('afterprint', unfitPages);

  // ---------- go ----------
  recalc(); syncTitles(); runCalc();
})();
